package com.qhit.interfaces;

/**
 * Created by Administrator on 2018/4/30 0030.
 */
public interface Engineer {


    /*
    判断一个正整数，后半部分的每一位，是否比前半部分的每一位都大
     */
    public void  judge(int i);

}

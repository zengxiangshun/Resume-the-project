package com.qhit.baseRoleFunction.pojo;


/**
* Created by GeneratorCode on 2018/12/02
*/

public class BaseRoleFunction {

    private Integer rmid;    //主键
    private Integer rid;    //角色id
    private Integer fid;    //功能id

    public Integer getRmid() { 
        return rmid;
    }
 
    public void setRmid(Integer rmid) { 
        this.rmid = rmid;
    }
 
    public Integer getRid() { 
        return rid;
    }
 
    public void setRid(Integer rid) { 
        this.rid = rid;
    }
 
    public Integer getFid() { 
        return fid;
    }
 
    public void setFid(Integer fid) { 
        this.fid = fid;
    }
 

 }
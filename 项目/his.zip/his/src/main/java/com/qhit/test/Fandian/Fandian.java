package com.qhit.test.Fandian;

/**
 * Created by 16682 on 2018/12/6.
 */
public interface Fandian {
    void tigongfancai();
    void tigongjiushui();
}

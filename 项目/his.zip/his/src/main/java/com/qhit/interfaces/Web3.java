package com.qhit.interfaces;

/**
 * Created by Administrator on 2018/5/1 0001.
 */
public class Web3 {

    public static void main(String[] args) {
        Engineer engineer = new EngineerHigh();
        engineer.judge(3573);
    }

}

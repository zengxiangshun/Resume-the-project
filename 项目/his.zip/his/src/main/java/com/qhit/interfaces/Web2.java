package com.qhit.interfaces;

/**
 * Created by Administrator on 2018/5/1 0001.
 */
public class Web2 {

    public static void main(String[] args) {
        Engineer engineer = new EngineerMiddle();
        engineer.judge(66785);
    }

}

package com.qhit.test.Fandian;

/**
 * Created by 16682 on 2018/12/6.
 */
public class Zhongcan implements Fandian{
    public  void tigongfancai(){
        System.out.println("提供中餐。。。。");
    }

    @Override
    public void tigongjiushui() {

    }
}

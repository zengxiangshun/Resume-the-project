package com.qhit.baseModule.pojo;


/**
* Created by GeneratorCode on 2018/11/29
*/

public class BaseModule {

    private Integer mid;    //模块ID
    private String mname;    //模块名称

    public Integer getMid() { 
        return mid;
    }
 
    public void setMid(Integer mid) { 
        this.mid = mid;
    }
 
    public String getMname() { 
        return mname;
    }
 
    public void setMname(String mname) { 
        this.mname = mname;
    }
 

 }
package com.qhit.user.controller;

import com.qhit.adminuser.pojo.Adminuser;
import com.qhit.adminuser.service.IAdminuserService;
import com.qhit.adminuser.service.impl.AdminuserServiceImpl;
import com.qhit.user.pojo.User;
import com.qhit.user.service.IUserService;
import com.qhit.user.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Administrator on 2018/11/4 0004.
 */
@WebServlet(name = "UserUpdateServlet",urlPatterns = "/UserUpdate")
public class UserUpdateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String uid = request.getParameter("uid");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String state = request.getParameter("state");
        String addr = request.getParameter("addr");

        IUserService service=new UserServiceImpl();
        User user= service.findById(Integer.parseInt(uid));
        user.setUsername(username);
        user.setPassword(password);
        user.setName(name);
        user.setPhone(phone);
        user.setEmail(email);
        user.setState(Integer.parseInt(state));
        user.setAddr(addr);
        boolean update = service.update(user);
        if (update){
            request.getRequestDispatcher("UserList").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

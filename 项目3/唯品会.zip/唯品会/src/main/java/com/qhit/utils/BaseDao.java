package com.qhit.utils;

import com.sun.org.glassfish.gmbal.Description;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.*;
import java.util.*;


/**
 * Created by Administrator on 2018/7/25 0025.
 */
public class BaseDao {

    public Connection conn = null;
    public ResultSet set = null;
    public PreparedStatement ps =null;
    /**
     * 获取连接
     * @return
     */

    public   Connection getConn(){
        String driverName = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/ishop?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC&zeroDateTimeBehavior=convertToNull";
        String username = "root";
        String password ="123456";
        try {
            //加载驱动
            Class.forName(driverName);
            //获取连接对象
            conn = DriverManager.getConnection(url,username,password);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    /**
     * 关闭连接
     */
    public  void closeConn(){
        if(set!=null) set=null;
        if(ps!=null) ps=null;
        if(conn!=null) conn = null;
    }

    /**
     * 插入数据
     * @param object
     */
    public boolean insert(Object object){
        try {
            // 获取连接
            Connection conn = getConn();
            // 获取类对象
            Class clazz = object.getClass();
            // 类名称(包名+类名)
            String className = clazz.getName().toLowerCase();
            String[] names = className.split("\\.");
            className = names[names.length-1].toLowerCase();
            // 获取所有属性(包括私有属性)
            Field[] fields = clazz.getDeclaredFields();
            // 拼接sql语句
            StringBuffer buffer = new StringBuffer("insert into ");
            buffer.append(className+(" values("));
            for(Field f:fields){
                String fname = f.getName();
                String  upperCaseFname = toUpperCaseFirstOne(fname);
                Method method = clazz.getMethod("get"+upperCaseFname);
                Object result = method.invoke(object);
                //获取注解
                Annotation[] as = f.getAnnotations();
                //没有注解
                if(as.length==0){
                    if(result==null|| "".equals(result)){
                        //空
                        buffer.append(null+",");
                    }else if(f.getType().getName().equals("java.lang.Integer")||f.getType().getName().equals("java.lang.Double")||f.getType().getName().equals("java.lang.Float")){
                        //数字
                        buffer.append(result+",");
                    }else{
                        //非数字
                        buffer.append("'"+result+"',");
                    }
                }
            }
            //最后一个逗号截掉
            buffer.deleteCharAt(buffer.length()-1);
            buffer.append(")");
            // 执行插入
            PreparedStatement ps = conn.prepareStatement(buffer.toString());
            //插入
            int row = ps.executeUpdate();
            closeConn();
            return row>0?true:false;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("插入失败");
        }finally {
            closeConn();
        }

        return  false;
    }

    public List freeFind(String sql){
        //通过sql获取表名  如果是多表，将数据存放在第一张表中
        String showTableName = findTableNameBySql(sql);
        List list = new ArrayList();
        try {
            // 获取连接
            Connection conn = getConn();
            // 获取执行对象
            ps = conn.prepareStatement(sql);


            //得到表名和类对象组成的Map集合
            Map<String,Class> tableClasses = new HashMap<>();
            //表名和实例对象组成的集合
            Map<String,List> tableObjects = new HashMap<>();
            ResultSet rs0 = ps.executeQuery();
            ResultSetMetaData metaData = rs0.getMetaData();
            while(rs0.next()){
                int count = metaData.getColumnCount();
                for (int i = 1; i <=count ; i++) {
                    String table = metaData.getTableName(i);
                    if(table==null||"".equals(table)){
                        table = showTableName;
                    }
                    String upperCaseTableName = toUpperCaseFirstOne(table);
                    Class clazz = Class.forName("com.qhit."+table+".pojo."+upperCaseTableName);
                    Object object = clazz.newInstance();
                    tableClasses.put(table,clazz);
                    List l = new ArrayList();
                    tableObjects.put(table,l);
                }
            }
            // 执行查询
            set = ps.executeQuery();
            int rownum=0;
            while(set.next()){
                //实例化对象
                //Object object =  clazz.newInstance();
                //通过元数据查看有多少个字段
                int count = metaData.getColumnCount();
                for (int i = 1; i <=count ; i++) {
                    //表名 类对象
                    String table = metaData.getTableName(i);
                    if(table==null || "".equals(table)){
                        table = showTableName;
                    }
                    Class clazz = tableClasses.get(table);
                    Object object = null;
                    // 表名 实例化对象集合
                    List l = tableObjects.get(table);
                    if(rownum==l.size()){
                        object=clazz.newInstance();
                        l.add(object);
                    }else{
                        object = l.get(rownum);
                    }

                    //列名 小写
                    String columnName = metaData.getColumnName(i);
                    String upperCaseColumnName = toUpperCaseFirstOne(columnName);
                    //列类型 大写
                    String type = metaData.getColumnTypeName(i);
                    Method m = null;
                    if(type.equals("VARCHAR")||type.equals("VARCHAR2")){
                        m = clazz.getMethod("set"+upperCaseColumnName,String.class);
                        m.invoke(object,set.getObject(i));
                    }else if(type.equals("INT")){
                        m = clazz.getMethod("set"+upperCaseColumnName,Integer.class);
                        m.invoke(object,set.getObject(i));
                    }else if(type.equals("FLOAT")){
                        m = clazz.getMethod("set"+upperCaseColumnName,Float.class);
                        m.invoke(object,set.getObject(i));
                    }else if(type.equals("DOUBLE")){
                        m = clazz.getMethod("set"+upperCaseColumnName,Double.class);
                        m.invoke(object,set.getObject(i));
                    }else if(type.equals("DATE")){
                        m = clazz.getMethod("set"+upperCaseColumnName,String.class);
                        String date = null;
                        if(set.getObject(i)!=null){
                            date = set.getDate(i).toString();
                        }
                        m.invoke(object,date);
                    }else if(type.equals("DATETIME")||type.equals("TIMESTAMP")){
                        m = clazz.getMethod("set"+upperCaseColumnName,String.class);
                        String datetime = null;
                        if(set.getObject(i)!=null){
                            datetime = set.getTimestamp(i).toString();
                        }
                        m.invoke(object,datetime);
                    }

                }
                rownum++;
            }
            //遍历tableObjects 执行set对象的方法
            Set<String> keyset = tableClasses.keySet();
            for(String key:keyset){
                Class clazz = tableClasses.get(key);
                Field[] fields = clazz.getDeclaredFields();
                for(Field f:fields){
                    Annotation[] as = f.getAnnotations();
                    for(Annotation a:as){
                        Description ds = (Description) a;
                        if("bean".equals(ds.value())){
                            String beanName = f.getName();
                            String upperCaseBeanName = toUpperCaseFirstOne(beanName);
                            Class beanClass = Class.forName("com.qhit."+beanName+".pojo."+upperCaseBeanName);  //bean类对象
                            Method method = clazz.getMethod("set"+upperCaseBeanName,beanClass);
                            List l = tableObjects.get(key);
                            for (int i = 0; i <l.size() ; i++) {
                                Object obj = l.get(i);
                                List bl = tableObjects.get(beanName);
                                if(bl!=null && bl.size()>0){
                                    Object bobj = bl.get(i);
                                    method.invoke(obj,bobj);
                                }
                            }

                        }
                    }

                }
            }


            list = tableObjects.get(showTableName.toLowerCase());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("查询失败");
        }finally {
            closeConn();
        }


        return list;
    }

    public String toUpperCaseFirstOne(String tableName) {
        String result = "";
        if(tableName!=null && !"".equals(tableName)){
            result = tableName.substring(0,1).toUpperCase()+tableName.substring(1);
        }
        return result;

    }

    // 通过sql语句获取表名
    public String findTableNameBySql(String sql) {
        int begin = sql.indexOf("from")+5;
        String tableName = sql.substring(begin).trim();
        if(tableName.indexOf(" ")!=-1){
            tableName = tableName.substring(0,tableName.indexOf(" "));
        }

        return tableName;
    }


    /**
     * 更新数据
     * @param object
     */
    public boolean update(Object object){
        try {
            // 获取连接
            Connection conn = getConn();
            // 获取类对象
            Class clazz = object.getClass();
            // 类名称(包名+类名)
            String className = clazz.getName().toLowerCase();
            String[] names = className.split("\\.");
            className = names[names.length-1].toLowerCase();
            // 获取所有属性(包括私有属性)
            Field[] fields = clazz.getDeclaredFields();
            // 拼接sql语句
            StringBuffer buffer = new StringBuffer("update ");
            buffer.append(className+(" set "));
            String whereSql = "";
            for(int i=0;i<fields.length;i++){
                Field f = fields[i];
                String fname = f.getName();
                //获取注解
                Annotation[] as = f.getAnnotations();
                String upperCaseFname = toUpperCaseFirstOne(fname);
                Method method = clazz.getMethod("get"+upperCaseFname);
                Object result = method.invoke(object);
                //属性没有注解
                if(as.length==0){
                    //主键
                    if(i==0){
                        whereSql = " where "+fname+"="+result;
                    }else if(result==null||"".equals(result)){
                        //空
                        buffer.append(fname+"=null,");
                    }else if(f.getType().getName().equals("java.lang.Integer")||f.getType().getName().equals("java.lang.Double")||f.getType().getName().equals("java.lang.Float")){
                        //数字
                        buffer.append(fname+"="+result+",");
                    }else{
                        //非数字
                        buffer.append(fname+"='"+result+"',");
                    }

                }
            }
            //最后一个逗号截掉
            buffer.deleteCharAt(buffer.length()-1);
            buffer.append(whereSql);
            // 执行更新
            PreparedStatement ps = conn.prepareStatement(buffer.toString());
            //更新
            int row = ps.executeUpdate();
            closeConn();
            return row>0?true:false;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("更新失败");
        }finally {
            closeConn();
        }

        return false;
    }


    /**
     * 删除数据
     * @param object
     */
    public boolean delete(Object object){
        try {
            // 获取连接
            Connection conn = getConn();
            // 获取类对象
            Class clazz = object.getClass();
            // 类名称(包名+类名)
            String className = clazz.getName().toLowerCase();
            String[] names = className.split("\\.");
            className = names[names.length-1].toLowerCase();
            // 获取所有属性(包括私有属性)
            Field[] fields = clazz.getDeclaredFields();
            // 拼接sql语句
            StringBuffer buffer = new StringBuffer("delete from  ");
            buffer.append(className+(" where  "));
            // 主键
            Field f = fields[0];
            String fname = f.getName();
            String upperCaseFname = toUpperCaseFirstOne(fname);
            Method method = clazz.getMethod("get"+upperCaseFname);
            Object result = method.invoke(object);
            buffer.append(fname+"="+result);

            // 执行删除
            PreparedStatement ps = conn.prepareStatement(buffer.toString());
            //删除
            int row = ps.executeUpdate();
            closeConn();
            return row>0?true:false;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("删除失败");
        }finally {
            closeConn();
        }

        return false;
    }


}

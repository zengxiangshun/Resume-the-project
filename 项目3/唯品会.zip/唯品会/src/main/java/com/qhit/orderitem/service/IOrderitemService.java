package com.qhit.orderitem.service;

import java.util.List;
import com.qhit.orderitem.pojo.Orderitem;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/11/08
*/

public interface IOrderitemService {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object id);

    List findAll();

    Orderitem findById(Object id);

    List<Orderitem> findBypage(Page page, String oid);
}
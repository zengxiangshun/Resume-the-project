package com.qhit.orderitem.pojo;

import com.qhit.orders.pojo.Orders;
import com.qhit.product.pojo.Product;
import com.sun.org.glassfish.gmbal.Description;

/**
* Created by GeneratorCode on 2018/11/08
*/

public class Orderitem {

    private Integer itemid;
    private Integer count;
    private Double subtotal;
    private Integer pid;
    private Integer oid;
    @Description("bean")
    private Product product;

    public String getCount1() {
        return count1;
    }

    public void setCount1(String count1) {
        this.count1 = count1;
    }

    @Description("bean")
    private Orders orders;
    private String count1;
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Orders getOrders() {
        return orders;
    }

    public void setOrders(Orders orders) {
        this.orders = orders;
    }

    public Integer getItemid() {
        return itemid;
    }
 
    public void setItemid(Integer itemid) { 
        this.itemid = itemid;
    }
 
    public Integer getCount() { 
        return count;
    }
 
    public void setCount(Integer count) { 
        this.count = count;
    }
 
    public Double getSubtotal() { 
        return subtotal;
    }
 
    public void setSubtotal(Double subtotal) { 
        this.subtotal = subtotal;
    }
 
    public Integer getPid() { 
        return pid;
    }
 
    public void setPid(Integer pid) { 
        this.pid = pid;
    }
 
    public Integer getOid() { 
        return oid;
    }
 
    public void setOid(Integer oid) { 
        this.oid = oid;
    }
 

 }
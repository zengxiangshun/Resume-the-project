package com.qhit.adminuser.service;

import java.util.List;
import com.qhit.adminuser.pojo.Adminuser;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/10/14
*/

public interface IAdminuserService {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object id);

    List findAll();

    Adminuser findById(Object id);

    Adminuser login(String username, String password);

    boolean findByUsername(String username);

    List<Adminuser> findBypage(Page page, Adminuser adminuser);
}
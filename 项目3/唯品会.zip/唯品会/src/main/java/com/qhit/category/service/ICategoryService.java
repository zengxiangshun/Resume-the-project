package com.qhit.category.service;

import java.util.List;
import com.qhit.category.pojo.Category;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/10/12
*/

public interface ICategoryService {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object id);

    List findAll();

    Category findById(Object id);

    List<Category> findBypage(Page page, Category category);


}
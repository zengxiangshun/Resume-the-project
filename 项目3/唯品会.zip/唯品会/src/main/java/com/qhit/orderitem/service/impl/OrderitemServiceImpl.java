package com.qhit.orderitem.service.impl;

import com.qhit.orderitem.service.IOrderitemService;
import java.util.List;
import com.qhit.orderitem.dao.IOrderitemDao;
import com.qhit.orderitem.dao.impl.OrderitemDaoImpl;
import com.qhit.orderitem.pojo.Orderitem;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/11/08
*/

public class OrderitemServiceImpl  implements IOrderitemService {

    IOrderitemDao dao = new OrderitemDaoImpl();

    @Override 
    public boolean insert(Object object) { 
        return dao.insert(object); 
    } 


    @Override 
    public boolean update(Object object) { 
        return dao.update(object); 
    } 


    @Override 
    public boolean delete(Object id) { 
        Orderitem orderitem = findById(id); 
        return dao.delete(orderitem); 
    } 


    @Override 
    public List findAll() { 
        return dao.findAll(); 
    } 


    @Override 
    public Orderitem findById(Object id) { 
        List<Orderitem> list = dao.findById(id); 
        return  list.get(0); 
    }

    @Override
    public List<Orderitem> findBypage(Page page, String oid) {
        String sql="select cast(count(*) as char) as count1 from orderitem";
        List<Orderitem> list = dao.freeFind(sql);
        String totalCount=list.get(0).getCount1();
        page.setTotalCount(Integer.parseInt(totalCount));
        int totalPage=page.getTotalCount()%page.getPageSize()==0?page.getTotalCount()/page.getPageSize():page.getTotalCount()/page.getPageSize()+1;
        page.setTotalPage(totalPage);
        int begin; int end;
        if (page.getTotalPage()<=10){
            begin=1;
            end=page.getTotalPage();
        }else if(page.getCurrentPage()<=5){
            begin=1;
            end=10;
        } else if (page.getCurrentPage()>=page.getTotalPage()-5){
            begin=page.getTotalPage()-9;
            end=page.getTotalPage();
        }else {
            begin=page.getCurrentPage()-4;
            end=page.getCurrentPage()+5;
        }
        page.setBegin(begin);
        page.setEnd(end);
        String sql1=" select * from orderitem o1 join orders o on o.oid=o1.oid\n" +
                "join product p on o1.pid=p.pid where o.oid="+oid+" limit "+(page.getCurrentPage()-1)*page.getPageSize()+","+page.getPageSize();
        List<Orderitem> list1 = dao.freeFind(sql1);
        return list1;
    }


}
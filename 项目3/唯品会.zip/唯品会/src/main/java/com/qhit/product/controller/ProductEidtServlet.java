package com.qhit.product.controller;

import com.qhit.category.pojo.Category;
import com.qhit.category.service.ICategoryService;
import com.qhit.category.service.impl.CategoryServiceImpl;
import com.qhit.categorysecond.pojo.Categorysecond;
import com.qhit.categorysecond.service.ICategorysecondService;
import com.qhit.categorysecond.service.impl.CategorysecondServiceImpl;
import com.qhit.product.pojo.Product;
import com.qhit.product.service.IProductService;
import com.qhit.product.service.impl.ProductServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2018/11/4 0004.
 */
@WebServlet(name = "ProductEidtServlet",urlPatterns = "/ProductEidt")
public class ProductEidtServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pid = request.getParameter("pid");
        IProductService service=new ProductServiceImpl();
        Product product=service.findById(pid);
        request.setAttribute("product",product);
       ICategorysecondService categorysecondService=new CategorysecondServiceImpl();
        List<Categorysecond> list = categorysecondService.findAll();
        request.setAttribute("list",list);
        request.getRequestDispatcher("product/ProductEidt.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

package com.qhit.orderitem.dao;

import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/11/08
*/

public interface IOrderitemDao {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object object);

    List freeFind(String sql);

    List findAll();

    List findById(Object id);

    List findByCount(Object count);

    List findBySubtotal(Object subtotal);

    List findByPid(Object pid);

    List findByOid(Object oid);

}
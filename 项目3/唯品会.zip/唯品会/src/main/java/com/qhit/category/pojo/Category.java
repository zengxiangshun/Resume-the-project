package com.qhit.category.pojo;

import com.qhit.categorysecond.pojo.Categorysecond;
import com.qhit.product.pojo.Product;
import com.sun.org.glassfish.gmbal.Description;

/**
* Created by GeneratorCode on 2018/10/12
*/

public class Category {

    private Integer cid;
    private String cname;
    @Description("un")
    private String count;
    @Description("bean")
    private Categorysecond categorysecond;
    @Description("bean")
    private Product product;

    public Categorysecond getCategorysecond() {
        return categorysecond;
    }

    public void setCategorysecond(Categorysecond categorysecond) {
        this.categorysecond = categorysecond;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
    public Integer getCid() { 
        return cid;
    }
 
    public void setCid(Integer cid) { 
        this.cid = cid;
    }
 
    public String getCname() { 
        return cname;
    }
 
    public void setCname(String cname) { 
        this.cname = cname;
    }
 

 }
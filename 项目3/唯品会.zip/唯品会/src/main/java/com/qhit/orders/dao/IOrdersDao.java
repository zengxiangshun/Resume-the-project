package com.qhit.orders.dao;

import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/11/08
*/

public interface IOrdersDao {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object object);

    List freeFind(String sql);

    List findAll();

    List findById(Object id);

    List findByTotal(Object total);

    List findByOrdertime(Object ordertime);

    List findByState(Object state);

    List findByName(Object name);

    List findByPhone(Object phone);

    List findByAddr(Object addr);

    List findByUid(Object uid);

}
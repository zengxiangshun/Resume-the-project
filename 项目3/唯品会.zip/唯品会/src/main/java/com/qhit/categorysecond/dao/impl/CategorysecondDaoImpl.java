package com.qhit.categorysecond.dao.impl;

import com.qhit.categorysecond.dao.ICategorysecondDao;
import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/10/14
*/

public class CategorysecondDaoImpl extends BaseDao implements ICategorysecondDao {

    @Override 
    public List findAll() { 
        String sql = "select * from categorysecond"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findById(Object id) { 
        String sql = "select * from categorysecond where csid='"+id+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByCsname(Object csname) { 
        String sql = "select * from categorysecond where csname='"+csname+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByCid(Object cid) { 
        String sql = "select * from categorysecond where cid='"+cid+"'"; 
        return freeFind(sql); 
    } 




}
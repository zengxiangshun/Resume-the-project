package com.qhit.orders.controller;

import com.qhit.categorysecond.pojo.Categorysecond;
import com.qhit.categorysecond.service.ICategorysecondService;
import com.qhit.categorysecond.service.impl.CategorysecondServiceImpl;
import com.qhit.orders.pojo.Orders;
import com.qhit.orders.service.IOrdersService;
import com.qhit.orders.service.impl.OrdersServiceImpl;
import com.qhit.utils.Page;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2018/11/2 0002.
 */
@WebServlet(name = "OrdersListServlet",urlPatterns = "/OrdersList")
public class OrdersListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String currentPage =request.getParameter("currentPage");
        String pageSize =request.getParameter("pageSize");
        String name =request.getParameter("name");
        String phone =request.getParameter("phone");
        Orders orders=new Orders();
        orders.setName(name);
        orders.setPhone(phone);
        Page page=new Page();
        if (currentPage==null){
            page.setCurrentPage(1);
        }else{
            page.setCurrentPage(Integer.parseInt(currentPage));
        }
        if (pageSize==null){
            page.setPageSize(10);
        }else{
            page.setPageSize(Integer.parseInt(pageSize));
        }
        IOrdersService service=new OrdersServiceImpl();
        List<Orders> list=service.findBypage(page,orders);
        request.setAttribute("list",list);
        request.setAttribute("page",page);
        request.setAttribute("orders",orders);
        request.getRequestDispatcher("oeders/OrdersList.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

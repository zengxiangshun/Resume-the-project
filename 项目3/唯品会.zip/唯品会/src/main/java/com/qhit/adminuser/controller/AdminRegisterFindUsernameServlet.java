package com.qhit.adminuser.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.qhit.adminuser.service.IAdminuserService;
import com.qhit.adminuser.service.impl.AdminuserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Administrator on 2018/11/2 0002.
 */
@WebServlet(name = "AdminRegisterFindUsernameServlet",urlPatterns = "/AdminRegisterFindUsername")
public class AdminRegisterFindUsernameServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username=request.getParameter("username");
        IAdminuserService service=new AdminuserServiceImpl();
        boolean flag=service.findByUsername(username);
        JSONObject json=new JSONObject();
        json.put("flag",flag);
        response.getWriter().write(json.toJSONString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

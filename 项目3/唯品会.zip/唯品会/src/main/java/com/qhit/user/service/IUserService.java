package com.qhit.user.service;

import java.util.List;
import com.qhit.user.pojo.User;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/10/14
*/

public interface IUserService {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object id);

    List findAll();

    User findById(Object id);

    boolean login(String username, String password);

    List<User> findBypage(Page page, User user);
}
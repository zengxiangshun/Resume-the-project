package com.qhit.adminuser.dao.impl;

import com.qhit.adminuser.dao.IAdminuserDao;
import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/10/14
*/

public class AdminuserDaoImpl extends BaseDao implements IAdminuserDao {

    @Override 
    public List findAll() { 
        String sql = "select * from adminuser"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findById(Object id) { 
        String sql = "select * from adminuser where uid='"+id+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByUsername(Object username) { 
        String sql = "select * from adminuser where username='"+username+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByPassword(Object password) { 
        String sql = "select * from adminuser where password='"+password+"'"; 
        return freeFind(sql); 
    } 




}
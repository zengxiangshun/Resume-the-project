package com.qhit.orders.service.impl;

import com.qhit.orders.service.IOrdersService;
import java.util.List;
import com.qhit.orders.dao.IOrdersDao;
import com.qhit.orders.dao.impl.OrdersDaoImpl;
import com.qhit.orders.pojo.Orders;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/11/08
*/

public class OrdersServiceImpl  implements IOrdersService {

    IOrdersDao dao = new OrdersDaoImpl();

    @Override 
    public boolean insert(Object object) { 
        return dao.insert(object); 
    } 


    @Override 
    public boolean update(Object object) { 
        return dao.update(object); 
    } 


    @Override 
    public boolean delete(Object id) { 
        Orders orders = findById(id); 
        return dao.delete(orders); 
    } 


    @Override 
    public List findAll() { 
        return dao.findAll(); 
    } 


    @Override 
    public Orders findById(Object id) { 
        List<Orders> list = dao.findById(id); 
        return  list.get(0); 
    }

    @Override
    public List<Orders> findBypage(Page page, Orders orders) {
        String sql="select cast(count(*) as char) as count from orders ";
        String whereStr = "where 1=1";
        if(orders.getName()!=null && !"".equals(orders.getName())){
            whereStr+=" and name like '%"+orders.getName()+"%'";
        }
        if(orders.getPhone()!=null && !"".equals(orders.getPhone())){
            whereStr+=" and phone like '%"+orders.getPhone()+"%'";
        }
        List<Orders> list = dao.freeFind(sql+whereStr);
        String totalCount=list.get(0).getCount();
        page.setTotalCount(Integer.parseInt(totalCount));
        int totalPage=page.getTotalCount()%page.getPageSize()==0?page.getTotalCount()/page.getPageSize():page.getTotalCount()/page.getPageSize()+1;
        page.setTotalPage(totalPage);
        int begin; int end;
        if (page.getTotalPage()<=10){
            begin=1;
            end=page.getTotalPage();
        }else if(page.getCurrentPage()<=5){
            begin=1;
            end=10;
        } else if (page.getCurrentPage()>=page.getTotalPage()-5){
            begin=page.getTotalPage()-9;
            end=page.getTotalPage();
        }else {
            begin=page.getCurrentPage()-4;
            end=page.getCurrentPage()+5;
        }
        page.setBegin(begin);
        page.setEnd(end);
        String sql1=" select * from orders "+whereStr+" limit "+(page.getCurrentPage()-1)*page.getPageSize()+","+page.getPageSize();
        List<Orders> list1 = dao.freeFind(sql1);
        return list1;
    }



}
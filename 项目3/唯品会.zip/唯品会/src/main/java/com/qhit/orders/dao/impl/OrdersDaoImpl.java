package com.qhit.orders.dao.impl;

import com.qhit.orders.dao.IOrdersDao;
import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/11/08
*/

public class OrdersDaoImpl extends BaseDao implements IOrdersDao {

    @Override 
    public List findAll() { 
        String sql = "select * from orders"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findById(Object id) { 
        String sql = "select * from orders where oid='"+id+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByTotal(Object total) { 
        String sql = "select * from orders where total='"+total+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByOrdertime(Object ordertime) { 
        String sql = "select * from orders where ordertime='"+ordertime+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByState(Object state) { 
        String sql = "select * from orders where state='"+state+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByName(Object name) { 
        String sql = "select * from orders where name='"+name+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByPhone(Object phone) { 
        String sql = "select * from orders where phone='"+phone+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByAddr(Object addr) { 
        String sql = "select * from orders where addr='"+addr+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByUid(Object uid) { 
        String sql = "select * from orders where uid='"+uid+"'"; 
        return freeFind(sql); 
    } 




}
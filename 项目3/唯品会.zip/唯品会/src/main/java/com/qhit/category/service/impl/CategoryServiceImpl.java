package com.qhit.category.service.impl;

import com.qhit.category.service.ICategoryService;
import java.util.List;
import com.qhit.category.dao.ICategoryDao;
import com.qhit.category.dao.impl.CategoryDaoImpl;
import com.qhit.category.pojo.Category;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/10/12
*/

public class CategoryServiceImpl  implements ICategoryService {

    ICategoryDao dao = new CategoryDaoImpl();

    @Override 
    public boolean insert(Object object) { 
        return dao.insert(object); 
    } 


    @Override 
    public boolean update(Object object) { 
        return dao.update(object); 
    } 


    @Override 
    public boolean delete(Object id) { 
        Category category = findById(id); 
        return dao.delete(category); 
    } 


    @Override 
    public List findAll() { 
        return dao.findAll(); 
    } 


    @Override 
    public Category findById(Object id) { 
        List<Category> list = dao.findById(id); 
        return  list.get(0); 
    }

    @Override
    public List<Category> findBypage(Page page, Category category) {
        String sql="select cast(count(*) as char) as count from category ";
        String whereStr = "where 1=1";
        if(category.getCname()!=null && !"".equals(category.getCname())){
            whereStr+=" and cname like '%"+category.getCname()+"%'";
        }
        List<Category> list = dao.freeFind(sql+whereStr);
        String totalCount=list.get(0).getCount();
        page.setTotalCount(Integer.parseInt(totalCount));
        int totalPage=page.getTotalCount()%page.getPageSize()==0?page.getTotalCount()/page.getPageSize():page.getTotalCount()/page.getPageSize()+1;
        page.setTotalPage(totalPage);
        int begin; int end;
        if (page.getTotalPage()<=10){
            begin=1;
            end=page.getTotalPage();
        }else if(page.getCurrentPage()<=5){
            begin=1;
            end=10;
        } else if (page.getCurrentPage()>=page.getTotalPage()-5){
            begin=page.getTotalPage()-9;
            end=page.getTotalPage();
        }else {
            begin=page.getCurrentPage()-4;
            end=page.getCurrentPage()+5;
        }
        page.setBegin(begin);
        page.setEnd(end);
        String sql1=" select * from category "+whereStr+" limit "+(page.getCurrentPage()-1)*page.getPageSize()+","+page.getPageSize();
        List<Category> list1 = dao.freeFind(sql1);
        return list1;
    }

}
package com.qhit.product.dao.impl;

import com.qhit.product.dao.IProductDao;
import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/11/06
*/

public class ProductDaoImpl extends BaseDao implements IProductDao {

    @Override 
    public List findAll() { 
        String sql = "select * from product"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findById(Object id) { 
        String sql = "select * from product where pid='"+id+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByPname(Object pname) { 
        String sql = "select * from product where pname='"+pname+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByMarketprice(Object marketprice) { 
        String sql = "select * from product where marketprice='"+marketprice+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByShopprice(Object shopprice) { 
        String sql = "select * from product where shopprice='"+shopprice+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByImage(Object image) { 
        String sql = "select * from product where image='"+image+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByPdesc(Object pdesc) { 
        String sql = "select * from product where pdesc='"+pdesc+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByIshot(Object ishot) { 
        String sql = "select * from product where ishot='"+ishot+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByPdate(Object pdate) { 
        String sql = "select * from product where pdate='"+pdate+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByCsid(Object csid) { 
        String sql = "select * from product where csid='"+csid+"'"; 
        return freeFind(sql); 
    } 




}
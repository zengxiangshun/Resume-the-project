package com.qhit.categorysecond.service.impl;

import com.qhit.categorysecond.service.ICategorysecondService;
import java.util.List;
import com.qhit.categorysecond.dao.ICategorysecondDao;
import com.qhit.categorysecond.dao.impl.CategorysecondDaoImpl;
import com.qhit.categorysecond.pojo.Categorysecond;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/10/14
*/

public class CategorysecondServiceImpl  implements ICategorysecondService {

    ICategorysecondDao dao = new CategorysecondDaoImpl();

    @Override 
    public boolean insert(Object object) { 
        return dao.insert(object); 
    } 


    @Override 
    public boolean update(Object object) { 
        return dao.update(object); 
    } 


    @Override 
    public boolean delete(Object id) { 
        Categorysecond categorysecond = findById(id); 
        return dao.delete(categorysecond); 
    } 


    @Override 
    public List findAll() { 
        return dao.findAll(); 
    } 


    @Override 
    public Categorysecond findById(Object id) { 
        List<Categorysecond> list = dao.findById(id); 
        return  list.get(0); 
    }

    @Override
    public List<Categorysecond> find() {
        String sql="SELECT * from categorysecond ca1 JOIN category ca2 on ca1.cid=ca2.cid";
        List list=dao.freeFind(sql);
        return list;
    }

    @Override
    public List<Categorysecond> findBypage(Page page, Categorysecond categorysecond) {
        String sql="select cast(count(*) as char) as count from categorysecond c1 join category  c2 on c1.cid=c2.cid ";
        String whereStr = "where 1=1";
        if(categorysecond.getCsname()!=null && !"".equals(categorysecond.getCsname())){
            whereStr+=" and c1.csname like '%"+categorysecond.getCsname()+"%'";
        }
        List<Categorysecond> list = dao.freeFind(sql+whereStr);
        String totalCount=list.get(0).getCount();
        page.setTotalCount(Integer.parseInt(totalCount));
        int totalPage=page.getTotalCount()%page.getPageSize()==0?page.getTotalCount()/page.getPageSize():page.getTotalCount()/page.getPageSize()+1;
        page.setTotalPage(totalPage);
        int begin; int end;
        if (page.getTotalPage()<=10){
            begin=1;
            end=page.getTotalPage();
        }else if(page.getCurrentPage()<=5){
            begin=1;
            end=10;
        } else if (page.getCurrentPage()>=page.getTotalPage()-5){
            begin=page.getTotalPage()-9;
            end=page.getTotalPage();
        }else {
            begin=page.getCurrentPage()-4;
            end=page.getCurrentPage()+5;
        }
        page.setBegin(begin);
        page.setEnd(end);
        String sql1=" select * from categorysecond c1 join category  c2 on c1.cid=c2.cid "+whereStr+" limit "+(page.getCurrentPage()-1)*page.getPageSize()+","+page.getPageSize();
        List<Categorysecond> list1 = dao.freeFind(sql1);
        return list1;
    }

    @Override
    public List<Categorysecond> findall() {
        String sql=" select * from categorysecond c1 join category  c2 on c1.cid=c2.cid";
        List<Categorysecond> list = dao.freeFind(sql);
        return list;
    }

    @Override
    public List<Categorysecond> findcid(Page page,  Categorysecond categorysecond) {
        String sql="select cast(count(*) as char) as count from categorysecond  cs join product p on cs.csid=p.csid ";
        String whereStr = " where 1=1";
        if(categorysecond.getCid()!=null && !"".equals(categorysecond.getCid())){
            whereStr+=" and cs.cid="+categorysecond.getCid();
        }
        if(categorysecond.getCsid()!=null && !"".equals(categorysecond.getCsid())){
            whereStr+=" and cs.csid="+categorysecond.getCsid();
        }
        List<Categorysecond> list = dao.freeFind(sql+whereStr);
        String totalCount=list.get(0).getCount();
        page.setTotalCount(Integer.parseInt(totalCount));
        int totalPage=page.getTotalCount()%page.getPageSize()==0?page.getTotalCount()/page.getPageSize():page.getTotalCount()/page.getPageSize()+1;
        page.setTotalPage(totalPage);
        int begin; int end;
        if (page.getTotalPage()<=10){
            begin=1;
            end=page.getTotalPage();
        }else if(page.getCurrentPage()<=5){
            begin=1;
            end=10;
        } else if (page.getCurrentPage()>=page.getTotalPage()-5){
            begin=page.getTotalPage()-9;
            end=page.getTotalPage();
        }else {
            begin=page.getCurrentPage()-4;
            end=page.getCurrentPage()+5;
        }
        page.setBegin(begin);
        page.setEnd(end);
        String sql1=" select * from categorysecond  cs join product p on cs.csid=p.csid  "+whereStr+" limit "+(page.getCurrentPage()-1)*page.getPageSize()+","+page.getPageSize();
        List<Categorysecond> list1 = dao.freeFind(sql1);
        return list1;
    }


}
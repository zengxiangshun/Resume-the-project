package com.qhit.product.service.impl;

import com.qhit.product.service.IProductService;
import java.util.List;
import com.qhit.product.dao.IProductDao;
import com.qhit.product.dao.impl.ProductDaoImpl;
import com.qhit.product.pojo.Product;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/11/06
*/

public class ProductServiceImpl  implements IProductService {

    IProductDao dao = new ProductDaoImpl();

    @Override 
    public boolean insert(Object object) { 
        return dao.insert(object); 
    } 


    @Override 
    public boolean update(Object object) { 
        return dao.update(object); 
    } 


    @Override 
    public boolean delete(Object id) { 
        Product product = findById(id); 
        return dao.delete(product); 
    } 


    @Override 
    public List findAll() { 
        return dao.findAll(); 
    } 


    @Override 
    public Product findById(Object id) { 
        List<Product> list = dao.findById(id); 
        return  list.get(0); 
    }

    @Override
    public List<Product> findBypage(Page page, Product product) {
        String sql="select cast(count(*) as char) as count from product p join categorysecond c on p.csid=c.csid ";
        String whereStr = "where 1=1";
        if(product.getPname()!=null && !"".equals(product.getPname())){
            whereStr+=" and p.pname like '%"+product.getPname()+"%'";
        }
        List<Product> list = dao.freeFind(sql+whereStr);
        String totalCount=list.get(0).getCount();
        page.setTotalCount(Integer.parseInt(totalCount));
        int totalPage=page.getTotalCount()%page.getPageSize()==0?page.getTotalCount()/page.getPageSize():page.getTotalCount()/page.getPageSize()+1;
        page.setTotalPage(totalPage);
        int begin; int end;
        if (page.getTotalPage()<=10){
            begin=1;
            end=page.getTotalPage();
        }else if(page.getCurrentPage()<=5){
            begin=1;
            end=10;
        } else if (page.getCurrentPage()>=page.getTotalPage()-5){
            begin=page.getTotalPage()-9;
            end=page.getTotalPage();
        }else {
            begin=page.getCurrentPage()-4;
            end=page.getCurrentPage()+5;
        }
        page.setBegin(begin);
        page.setEnd(end);
        String sql1=" select * from product p join categorysecond c on p.csid=c.csid "+whereStr+" limit "+(page.getCurrentPage()-1)*page.getPageSize()+","+page.getPageSize();
        List<Product> list1 = dao.freeFind(sql1);
        return list1;
    }





}
package com.qhit.adminuser.controller;

import com.qhit.adminuser.pojo.Adminuser;
import com.qhit.adminuser.service.IAdminuserService;
import com.qhit.adminuser.service.impl.AdminuserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Administrator on 2018/11/2 0002.
 */
@WebServlet(name = "AdminRegisterServlet",urlPatterns = "/AdminRegister")
public class AdminRegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        Adminuser adminuser=new Adminuser();
        adminuser.setPassword(username);
        adminuser.setPassword(password);
        IAdminuserService service=new AdminuserServiceImpl();
        boolean insert = service.insert(adminuser);
        if (insert){
            request.getRequestDispatcher("admin/AdminLogin.jsp").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

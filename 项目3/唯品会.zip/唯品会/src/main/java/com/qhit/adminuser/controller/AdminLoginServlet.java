package com.qhit.adminuser.controller;

import com.qhit.adminuser.pojo.Adminuser;
import com.qhit.adminuser.service.IAdminuserService;
import com.qhit.adminuser.service.impl.AdminuserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Administrator on 2018/11/2 0002.
 */
@WebServlet(name = "AdminLoginServlet",urlPatterns = "/AdminLogin")
public class AdminLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        IAdminuserService service=new AdminuserServiceImpl();
        Adminuser adminuser=service.login(username,password);
        if (adminuser==null){
            request.setAttribute("info","密码或用户名错误");
            request.getRequestDispatcher("admin/AdminLogin.jsp").forward(request,response);
        }else {
            Cookie cookie1=new Cookie("username",adminuser.getUsername());
            Cookie cookie2=new Cookie("password",adminuser.getPassword());
            response.addCookie(cookie1);
            response.addCookie(cookie2);
            cookie1.setMaxAge(7*24*60*60);
            cookie2.setMaxAge(7*24*60*60);
            request.getSession().setAttribute("username",username);
            request.getRequestDispatcher("home/home.jsp").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

package com.qhit.adminuser.service.impl;

import com.qhit.adminuser.service.IAdminuserService;
import java.util.List;
import com.qhit.adminuser.dao.IAdminuserDao;
import com.qhit.adminuser.dao.impl.AdminuserDaoImpl;
import com.qhit.adminuser.pojo.Adminuser;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/10/14
*/

public class AdminuserServiceImpl  implements IAdminuserService {

    IAdminuserDao dao = new AdminuserDaoImpl();

    @Override 
    public boolean insert(Object object) { 
        return dao.insert(object); 
    } 


    @Override 
    public boolean update(Object object) { 
        return dao.update(object); 
    } 


    @Override 
    public boolean delete(Object id) { 
        Adminuser adminuser = findById(id); 
        return dao.delete(adminuser); 
    } 


    @Override 
    public List findAll() { 
        return dao.findAll(); 
    } 


    @Override 
    public Adminuser findById(Object id) { 
        List<Adminuser> list = dao.findById(id); 
        return  list.get(0); 
    }

    @Override
    public Adminuser login(String username, String password) {
        String sql="select * from adminuser where username='"+username+"' and password='"+password+"'";
        List<Adminuser> list = dao.freeFind(sql);
        if (list!=null && list.size()>0){
            return list.get(0);
        }
        return null;
    }

    @Override
    public boolean findByUsername(String username) {
        String sql="select * from adminuser where username='"+username+"'";
        List<Adminuser> list = dao.freeFind(sql);
        if (list!=null && list.size()>0){
            return true;
        }
        return false;
    }

    @Override
    public List<Adminuser> findBypage(Page page, Adminuser adminuser) {

        String sql="select cast(count(*) as char) as count from adminuser ";
        String whereStr = "where 1=1";
        if(adminuser.getUsername()!=null && !"".equals(adminuser.getUsername())){
            whereStr+=" and username like '%"+adminuser.getUsername()+"%'";
        }
        List<Adminuser> list = dao.freeFind(sql+whereStr);
        String totalCount=list.get(0).getCount();
        page.setTotalCount(Integer.parseInt(totalCount));
        int totalPage=page.getTotalCount()%page.getPageSize()==0?page.getTotalCount()/page.getPageSize():page.getTotalCount()/page.getPageSize()+1;
        page.setTotalPage(totalPage);
        int begin; int end;
        if (page.getTotalPage()<=10){
            begin=1;
            end=page.getTotalPage();
        }else if(page.getCurrentPage()<=5){
            begin=1;
            end=10;
        } else if (page.getCurrentPage()>=page.getTotalPage()-5){
            begin=page.getTotalPage()-9;
            end=page.getTotalPage();
        }else {
            begin=page.getCurrentPage()-4;
            end=page.getCurrentPage()+5;
        }
        page.setBegin(begin);
        page.setEnd(end);
        String sql1=" select * from adminuser "+whereStr+" limit "+(page.getCurrentPage()-1)*page.getPageSize()+","+page.getPageSize();
        List<Adminuser> list1 = dao.freeFind(sql1);
        return list1;
    }


}
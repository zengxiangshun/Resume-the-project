package com.qhit.categorysecond.controller;

import com.qhit.category.pojo.Category;
import com.qhit.category.service.ICategoryService;
import com.qhit.category.service.impl.CategoryServiceImpl;
import com.qhit.categorysecond.pojo.Categorysecond;
import com.qhit.categorysecond.service.ICategorysecondService;
import com.qhit.categorysecond.service.impl.CategorysecondServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Administrator on 2018/11/4 0004.
 */
@WebServlet(name = "CategorySecondUpdateServlet",urlPatterns = "/CategorySecondUpdate")
public class CategorySecondUpdateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String csid = request.getParameter("csid");
        String csname = request.getParameter("csname");
        String select = request.getParameter("select");
        ICategorysecondService service=new CategorysecondServiceImpl();
        Categorysecond categorysecond = service.findById(Integer.parseInt(csid));
        categorysecond.setCsid(Integer.parseInt(csid));
        categorysecond.setCsname(csname);
        categorysecond.setCid(Integer.parseInt(select));
        boolean update = service.update(categorysecond);
        if (update){
            request.getRequestDispatcher("CategorySecondList").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

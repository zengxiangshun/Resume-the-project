package com.qhit.categorysecond.dao;

import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/10/14
*/

public interface ICategorysecondDao {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object object);

    List freeFind(String sql);

    List findAll();

    List findById(Object id);

    List findByCsname(Object csname);

    List findByCid(Object cid);

}
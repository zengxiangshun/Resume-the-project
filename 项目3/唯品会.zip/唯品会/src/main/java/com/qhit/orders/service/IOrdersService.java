package com.qhit.orders.service;

import java.util.List;

import com.qhit.orders.pojo.Orders;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/11/08
*/

public interface IOrdersService {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object id);

    List findAll();

    Orders findById(Object id);

    List<Orders> findBypage(Page page, Orders orders);

}
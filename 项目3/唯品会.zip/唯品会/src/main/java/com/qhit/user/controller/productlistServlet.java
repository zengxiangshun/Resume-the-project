package com.qhit.user.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.qhit.product.pojo.Product;
import com.qhit.product.service.IProductService;
import com.qhit.product.service.impl.ProductServiceImpl;
import com.qhit.utils.Page;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2018/11/14 0014.
 */
@WebServlet(name = "productlistServlet",urlPatterns = "/productlist")
public class productlistServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        IProductService service=new ProductServiceImpl();
        List<Product> list=service.findAll();
        JSONObject json=new JSONObject();
        json.put("list",list);
        response.getWriter().write(json.toJSONString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}

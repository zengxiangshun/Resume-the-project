package com.qhit.adminuser.controller;

import com.qhit.adminuser.pojo.Adminuser;
import com.qhit.adminuser.service.IAdminuserService;
import com.qhit.adminuser.service.impl.AdminuserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Administrator on 2018/11/4 0004.
 */
@WebServlet(name = "AdminEidtServlet",urlPatterns = "/AdminEidt")
public class AdminEidtServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uid = request.getParameter("uid");
        IAdminuserService service=new AdminuserServiceImpl();
        Adminuser adminuser=service.findById(uid);
        request.setAttribute("adminuser",adminuser);
        request.getRequestDispatcher("admin/AdminEidt.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

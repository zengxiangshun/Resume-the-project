package com.qhit.product.controller;

import com.qhit.product.pojo.Product;
import com.qhit.product.service.IProductService;
import com.qhit.product.service.impl.ProductServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Administrator on 2018/11/4 0004.
 */
@WebServlet(name = "ProductAddServlet",urlPatterns = "/ProductAdd")
public class ProductAddServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String pname = request.getParameter("pname");
        String marketprice = request.getParameter("marketprice");
        String shopprice = request.getParameter("shopprice");
        String image = request.getParameter("image");
        String ishot = request.getParameter("ishot");
        String pdesc = request.getParameter("pdesc");
        String select = request.getParameter("select");
        Product product=new Product();
        product.setPname(pname);
        product.setMarketprice(Double.parseDouble(marketprice));
        product.setShopprice(Double.parseDouble(shopprice));
        product.setImage(image);
        product.setIshot(Integer.parseInt(ishot));
        product.setPdesc(pdesc);
        product.setCsid(Integer.parseInt(select));
        Date date=new Date();
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String pdate = format.format(date);
        product.setPdate(pdate);
        IProductService service=new ProductServiceImpl();
        boolean update = service.insert(product);
        if (update){
            request.getRequestDispatcher("ProductList").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

package com.qhit.product.controller;

import com.qhit.product.pojo.Product;
import com.qhit.product.service.IProductService;
import com.qhit.product.service.impl.ProductServiceImpl;
import com.qhit.utils.Page;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2018/11/6 0006.
 */
@WebServlet(name = "ProductListServlet",urlPatterns = "/ProductList")
public class ProductListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String currentPage =request.getParameter("currentPage");
        String pageSize =request.getParameter("pageSize");
        String pname =request.getParameter("pname");
        Product product=new Product();
        product.setPname(pname);
        Page page=new Page();
        if (currentPage==null){
            page.setCurrentPage(1);
        }else{
            page.setCurrentPage(Integer.parseInt(currentPage));
        }
        if (pageSize==null){
            page.setPageSize(10);
        }else{
            page.setPageSize(Integer.parseInt(pageSize));
        }
        IProductService service=new ProductServiceImpl();
        List<Product> list=service.findBypage(page,product);
        request.setAttribute("list",list);
        request.setAttribute("page",page);
        request.setAttribute("product",product);
        request.getRequestDispatcher("product/ProductList.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}

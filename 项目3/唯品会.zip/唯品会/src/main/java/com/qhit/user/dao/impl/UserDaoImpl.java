package com.qhit.user.dao.impl;

import com.qhit.user.dao.IUserDao;
import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/10/14
*/

public class UserDaoImpl extends BaseDao implements IUserDao {

    @Override 
    public List findAll() { 
        String sql = "select * from user"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findById(Object id) { 
        String sql = "select * from user where uid='"+id+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByUsername(Object username) { 
        String sql = "select * from user where username='"+username+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByPassword(Object password) { 
        String sql = "select * from user where password='"+password+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByName(Object name) { 
        String sql = "select * from user where name='"+name+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByEmail(Object email) { 
        String sql = "select * from user where email='"+email+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByPhone(Object phone) { 
        String sql = "select * from user where phone='"+phone+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByAddr(Object addr) { 
        String sql = "select * from user where addr='"+addr+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByState(Object state) { 
        String sql = "select * from user where state='"+state+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByCode(Object code) { 
        String sql = "select * from user where code='"+code+"'"; 
        return freeFind(sql); 
    } 




}
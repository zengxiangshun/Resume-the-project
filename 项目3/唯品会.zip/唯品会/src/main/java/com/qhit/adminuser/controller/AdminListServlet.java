package com.qhit.adminuser.controller;

import com.qhit.adminuser.pojo.Adminuser;
import com.qhit.adminuser.service.IAdminuserService;
import com.qhit.adminuser.service.impl.AdminuserServiceImpl;
import com.qhit.utils.Page;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2018/11/2 0002.
 */
@WebServlet(name = "AdminListServlet",urlPatterns = "/AdminList")
public class AdminListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String currentPage =request.getParameter("currentPage");
        String pageSize =request.getParameter("pageSize");
        String username =request.getParameter("username");
        Adminuser adminuser=new Adminuser();
        adminuser.setUsername(username);
        Page page=new Page();
        if (currentPage==null){
            page.setCurrentPage(1);
        }else{
            page.setCurrentPage(Integer.parseInt(currentPage));
        }
        if (pageSize==null){
            page.setPageSize(10);
        }else{
            page.setPageSize(Integer.parseInt(pageSize));
        }
        IAdminuserService service=new AdminuserServiceImpl();
        List<Adminuser> list=service.findBypage(page,adminuser);
        request.setAttribute("list",list);
        request.setAttribute("page",page);
        request.setAttribute("adminuser",adminuser);
        request.getRequestDispatcher("admin/AdminuserList.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

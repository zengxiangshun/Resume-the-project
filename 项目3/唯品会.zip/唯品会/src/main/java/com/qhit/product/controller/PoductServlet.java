package com.qhit.product.controller;

import com.qhit.category.pojo.Category;
import com.qhit.category.service.ICategoryService;
import com.qhit.category.service.impl.CategoryServiceImpl;
import com.qhit.categorysecond.pojo.Categorysecond;
import com.qhit.categorysecond.service.ICategorysecondService;
import com.qhit.categorysecond.service.impl.CategorysecondServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2018/11/6 0006.
 */
@WebServlet(name = "ProductServlet",urlPatterns = "/productadd")
public class PoductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ICategorysecondService service=new CategorysecondServiceImpl();
        List<Categorysecond> categorysecond = service.findAll();
        request.setAttribute("categorysecond",categorysecond);
        request.getRequestDispatcher("product/ProductAdd.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

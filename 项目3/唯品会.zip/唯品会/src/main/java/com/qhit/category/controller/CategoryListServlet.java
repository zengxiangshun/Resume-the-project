package com.qhit.category.controller;

import com.qhit.category.pojo.Category;
import com.qhit.category.service.ICategoryService;
import com.qhit.category.service.impl.CategoryServiceImpl;
import com.qhit.user.pojo.User;
import com.qhit.user.service.IUserService;
import com.qhit.user.service.impl.UserServiceImpl;
import com.qhit.utils.Page;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2018/11/2 0002.
 */
@WebServlet(name = "CategoryListServlet",urlPatterns = "/CategoryList")
public class CategoryListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String currentPage =request.getParameter("currentPage");
        String pageSize =request.getParameter("pageSize");
        String cname =request.getParameter("cname");
        Category category=new Category();
        category.setCname(cname);
        Page page=new Page();
        if (currentPage==null){
            page.setCurrentPage(1);
        }else{
            page.setCurrentPage(Integer.parseInt(currentPage));
        }
        if (pageSize==null){
            page.setPageSize(10);
        }else{
            page.setPageSize(Integer.parseInt(pageSize));
        }
        ICategoryService service=new CategoryServiceImpl();
        List<Category> categoryList=service.findBypage(page,category);
        request.setAttribute("categoryList",categoryList);
        request.setAttribute("page",page);
        request.setAttribute("category",category);
        request.getRequestDispatcher("category/CategoryList.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

package com.qhit.categorysecond.controller;

import com.qhit.category.pojo.Category;
import com.qhit.category.service.ICategoryService;
import com.qhit.category.service.impl.CategoryServiceImpl;
import com.qhit.categorysecond.pojo.Categorysecond;
import com.qhit.categorysecond.service.ICategorysecondService;
import com.qhit.categorysecond.service.impl.CategorysecondServiceImpl;
import com.qhit.utils.Page;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2018/11/2 0002.
 */
@WebServlet(name = "CategorySecondListServlet",urlPatterns = "/CategorySecondList")
public class CategorySecondListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String currentPage =request.getParameter("currentPage");
        String pageSize =request.getParameter("pageSize");
        String csname =request.getParameter("csname");
        Categorysecond categorysecond=new Categorysecond();
        categorysecond.setCsname(csname);
        Page page=new Page();
        if (currentPage==null){
            page.setCurrentPage(1);
        }else{
            page.setCurrentPage(Integer.parseInt(currentPage));
        }
        if (pageSize==null){
            page.setPageSize(10);
        }else{
            page.setPageSize(Integer.parseInt(pageSize));
        }
        ICategorysecondService service=new CategorysecondServiceImpl();
        List<Categorysecond> list=service.findBypage(page,categorysecond);
        request.setAttribute("list",list);
        request.setAttribute("page",page);
        request.setAttribute("categorysecond",categorysecond );
        request.getRequestDispatcher("categorysecond/CategorySecondList.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

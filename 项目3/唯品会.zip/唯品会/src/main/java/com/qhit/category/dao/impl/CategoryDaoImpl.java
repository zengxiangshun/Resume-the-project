package com.qhit.category.dao.impl;

import com.qhit.category.dao.ICategoryDao;
import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/10/12
*/

public class CategoryDaoImpl extends BaseDao implements ICategoryDao {

    @Override 
    public List findAll() { 
        String sql = "select * from category"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findById(Object id) { 
        String sql = "select * from category where cid='"+id+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByCname(Object cname) { 
        String sql = "select * from category where cname='"+cname+"'"; 
        return freeFind(sql); 
    } 




}
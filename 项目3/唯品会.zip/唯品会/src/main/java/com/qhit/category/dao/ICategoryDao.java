package com.qhit.category.dao;

import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/10/12
*/

public interface ICategoryDao {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object object);

    List freeFind(String sql);

    List findAll();

    List findById(Object id);

    List findByCname(Object cname);

}
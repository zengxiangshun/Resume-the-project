package com.qhit.orderitem.dao.impl;

import com.qhit.orderitem.dao.IOrderitemDao;
import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/11/08
*/

public class OrderitemDaoImpl extends BaseDao implements IOrderitemDao {

    @Override 
    public List findAll() { 
        String sql = "select * from orderitem"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findById(Object id) { 
        String sql = "select * from orderitem where itemid='"+id+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByCount(Object count) { 
        String sql = "select * from orderitem where count='"+count+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findBySubtotal(Object subtotal) { 
        String sql = "select * from orderitem where subtotal='"+subtotal+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByPid(Object pid) { 
        String sql = "select * from orderitem where pid='"+pid+"'"; 
        return freeFind(sql); 
    } 


    @Override 
    public List findByOid(Object oid) { 
        String sql = "select * from orderitem where oid='"+oid+"'"; 
        return freeFind(sql); 
    } 




}
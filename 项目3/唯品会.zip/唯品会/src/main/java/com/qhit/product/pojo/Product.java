package com.qhit.product.pojo;

import com.qhit.categorysecond.pojo.Categorysecond;
import com.sun.org.glassfish.gmbal.Description;

/**
* Created by GeneratorCode on 2018/11/06
*/

public class Product {

    private Integer pid;
    private String pname;
    private Double marketprice;
    private Double shopprice;
    private String image;
    private String pdesc;
    private Integer ishot;
    private String pdate;
    private Integer csid;
    @Description("bean")
    private Categorysecond categorysecond;

    public Categorysecond getCategorysecond() {
        return categorysecond;
    }

    public void setCategorysecond(Categorysecond categorysecond) {
        this.categorysecond = categorysecond;
    }

    @Description("un")
    private String count;

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public Integer getPid() { 
        return pid;
    }
 
    public void setPid(Integer pid) { 
        this.pid = pid;
    }
 
    public String getPname() { 
        return pname;
    }
 
    public void setPname(String pname) { 
        this.pname = pname;
    }
 
    public Double getMarketprice() { 
        return marketprice;
    }
 
    public void setMarketprice(Double marketprice) { 
        this.marketprice = marketprice;
    }
 
    public Double getShopprice() { 
        return shopprice;
    }
 
    public void setShopprice(Double shopprice) { 
        this.shopprice = shopprice;
    }
 
    public String getImage() { 
        return image;
    }
 
    public void setImage(String image) { 
        this.image = image;
    }
 
    public String getPdesc() { 
        return pdesc;
    }
 
    public void setPdesc(String pdesc) { 
        this.pdesc = pdesc;
    }
 
    public Integer getIshot() { 
        return ishot;
    }
 
    public void setIshot(Integer ishot) { 
        this.ishot = ishot;
    }
 
    public String getPdate() { 
        return pdate;
    }
 
    public void setPdate(String pdate) { 
        this.pdate = pdate;
    }
 
    public Integer getCsid() { 
        return csid;
    }
 
    public void setCsid(Integer csid) { 
        this.csid = csid;
    }
 

 }
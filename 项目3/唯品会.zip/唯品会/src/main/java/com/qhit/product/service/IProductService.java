package com.qhit.product.service;

import java.util.List;

import com.qhit.category.pojo.Category;
import com.qhit.product.pojo.Product;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/11/06
*/

public interface IProductService {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object id);

    List findAll();

    Product findById(Object id);

    List<Product> findBypage(Page page, Product product);


}
package com.qhit.user.dao;

import com.qhit.utils.BaseDao;
import java.util.List;

/**
* Created by GeneratorCode on 2018/10/14
*/

public interface IUserDao {

    boolean insert(Object object);

    boolean  update(Object object);

    boolean delete(Object object);

    List freeFind(String sql);

    List findAll();

    List findById(Object id);

    List findByUsername(Object username);

    List findByPassword(Object password);

    List findByName(Object name);

    List findByEmail(Object email);

    List findByPhone(Object phone);

    List findByAddr(Object addr);

    List findByState(Object state);

    List findByCode(Object code);

}
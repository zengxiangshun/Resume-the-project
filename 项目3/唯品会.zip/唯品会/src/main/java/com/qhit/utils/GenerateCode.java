package com.qhit.utils;

/**
 * Created by Administrator on 2018/7/25 0025.
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 根据表名，自动生成javabean,dao,dao实现类,service,service实现类
 */
public class GenerateCode {

    private static String tableName = "orderitem";
    private static String tableChineseName = "订单";
    private static BaseDao dao = new BaseDao();

    public static void main(String[] args) throws Exception {

        //连接
        Connection conn = dao.getConn();
        String sql = "select * from "+tableName;
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        //元数据
        ResultSetMetaData metaData = rs.getMetaData();
        rs.close();
        //字段注释
        String[] comments = findComments(conn, metaData);
        // 表名首字母大写
        String upperCaseTableName = dao.toUpperCaseFirstOne(tableName);
        //文件输出位置
        File dir = new File("d:\\codeout");
        if(!dir.exists()){
            dir.mkdirs();
        }
        //删除文件夹下的所有文件
        delAllFile(dir.getAbsolutePath());
        //创建 pojo dao service 文件夹
        makeSomeDirs(dir);


        //javabean
        String beanName = upperCaseTableName+".java";
        BufferedWriter beanWriter = new BufferedWriter(new FileWriter(dir.getAbsolutePath()+"\\com\\qhit\\"+tableName+"\\pojo\\"+beanName));
        //dao
        String daoName = "I"+upperCaseTableName+"Dao.java";
        BufferedWriter daoWriter= new BufferedWriter(new FileWriter(dir.getAbsolutePath()+"\\com\\qhit\\"+tableName+"\\dao\\"+daoName));
        //dao实现类
        String daoImplName = upperCaseTableName+"DaoImpl.java";
        BufferedWriter daoImplWriter= new BufferedWriter(new FileWriter(dir.getAbsolutePath()+"\\com\\qhit\\"+tableName+"\\dao\\impl\\"+daoImplName));
        //service
        String serviceName = "I"+upperCaseTableName+"Service.java";
        BufferedWriter serviceWriter= new BufferedWriter(new FileWriter(dir.getAbsolutePath()+"\\com\\qhit\\"+tableName+"\\service\\"+serviceName));
        //service实现类
        String serviceImplName = upperCaseTableName+"ServiceImpl.java";
        BufferedWriter serviceImplWriter= new BufferedWriter(new FileWriter(dir.getAbsolutePath()+"\\com\\qhit\\"+tableName+"\\service\\impl\\"+serviceImplName));


        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        String now = format.format(date);


        // dao
        generateDao(metaData,upperCaseTableName, daoWriter, now);
        //dao实现类
        generateDaoImpl(metaData,upperCaseTableName, daoImplWriter, now);
        //javabean
        generateJavaBean(metaData, upperCaseTableName, beanWriter, now);
        // service
        generateService(metaData,upperCaseTableName, serviceWriter, now);
        //service实现类
        generateServiceImpl(metaData,upperCaseTableName, serviceImplWriter, now);

        System.out.println("执行成功");

    }



    private static void generateJavaBean(ResultSetMetaData metaData, String upperCaseTableName, BufferedWriter beanWriter, String now) throws IOException, SQLException {
        //javabean写头部
        beanWriter.write("package com.qhit."+tableName+".pojo;");
        beanWriter.newLine();
        beanWriter.newLine();
        beanWriter.write("import com.sun.org.glassfish.gmbal.Description;");
        beanWriter.newLine();
        beanWriter.newLine();
        beanWriter.write("/**");
        beanWriter.newLine();
        beanWriter.write("* Created by GeneratorCode on "+now);
        beanWriter.newLine();
        beanWriter.write("*/");
        beanWriter.newLine();
        beanWriter.newLine();
        beanWriter.write("public class "+upperCaseTableName+" {");
        beanWriter.newLine();
        beanWriter.newLine();
        //存储get,set方法
        StringBuffer buffer = new StringBuffer("\r\n");
        int count = metaData.getColumnCount();
        for(int i=1;i<=count;i++){
            //列名 小写
            String columnName = metaData.getColumnName(i);
            String upperCaseColumnName = dao.toUpperCaseFirstOne(columnName);
            //列类型 大写
            String type = metaData.getColumnTypeName(i);
            if(type.equals("VARCHAR")||type.equals("VARCHAR2")||type.equals("TIME")||type.equals("DATE")||type.equals("DATETIME")||type.equals("TIMESTAMP")){
                    beanWriter.write("    private String "+columnName+";");
                    beanWriter.newLine();

                    buffer.append("    public String get"+upperCaseColumnName+"() { \r\n");
                    buffer.append("        return "+columnName+";\r\n");
                    buffer.append("    }\r\n \r\n");
                    buffer.append("    public void set"+upperCaseColumnName+"(String "+columnName+") { \r\n");
                    buffer.append("        this."+columnName+" = "+columnName+";\r\n");
                    buffer.append("    }\r\n \r\n");

            }else if(type.equals("INT")){
                beanWriter.write("    private Integer "+columnName+";");
                beanWriter.newLine();

                buffer.append("    public Integer get"+upperCaseColumnName+"() { \r\n");
                buffer.append("        return "+columnName+";\r\n");
                buffer.append("    }\r\n \r\n");
                buffer.append("    public void set"+upperCaseColumnName+"(Integer "+columnName+") { \r\n");
                buffer.append("        this."+columnName+" = "+columnName+";\r\n");
                buffer.append("    }\r\n \r\n");
            }else if(type.equals("FLOAT")){
                beanWriter.write("    private Float "+columnName+";");
                beanWriter.newLine();

                buffer.append("    public Float get"+upperCaseColumnName+"() { \r\n");
                buffer.append("        return "+columnName+";\r\n");
                buffer.append("    }\r\n \r\n");
                buffer.append("    public void set"+upperCaseColumnName+"(Float "+columnName+") { \r\n");
                buffer.append("        this."+columnName+" = "+columnName+";\r\n");
                buffer.append("    }\r\n \r\n");
            }else if(type.equals("DOUBLE")){
                beanWriter.write("    private Double "+columnName+";");
                beanWriter.newLine();

                buffer.append("    public Double get"+upperCaseColumnName+"() { \r\n");
                buffer.append("        return "+columnName+";\r\n");
                buffer.append("    }\r\n \r\n");
                buffer.append("    public void set"+upperCaseColumnName+"(Double "+columnName+") { \r\n");
                buffer.append("        this."+columnName+" = "+columnName+";\r\n");
                buffer.append("    }\r\n \r\n");
            }
        }
        beanWriter.write(buffer.toString()+"\r\n }");
        //关流
        beanWriter.close();
    }

    private static void generateDaoImpl(ResultSetMetaData metaData,String upperCaseTableName, BufferedWriter daoImplWriter, String now) throws IOException, SQLException {
        daoImplWriter.write("package com.qhit."+tableName+".dao.impl;");
        daoImplWriter.newLine();
        daoImplWriter.newLine();
        daoImplWriter.write("import com.qhit."+tableName+".dao.I"+upperCaseTableName+"Dao;");
        daoImplWriter.newLine();
        daoImplWriter.write("import com.qhit.utils.BaseDao;");
        daoImplWriter.newLine();
        daoImplWriter.write("import java.util.List;");
        daoImplWriter.newLine();
        daoImplWriter.newLine();
        daoImplWriter.write("/**");
        daoImplWriter.newLine();
        daoImplWriter.write("* Created by GeneratorCode on "+now);
        daoImplWriter.newLine();
        daoImplWriter.write("*/");
        daoImplWriter.newLine();
        daoImplWriter.newLine();
        daoImplWriter.write("public class "+upperCaseTableName+"DaoImpl extends BaseDao implements I"+upperCaseTableName+"Dao {");
        daoImplWriter.newLine();
        daoImplWriter.newLine();
        daoImplWriter.write("    @Override \r\n");
        daoImplWriter.write("    public List findAll() { \r\n");
        daoImplWriter.write("        String sql = \"select * from "+tableName+"\"; \r\n");
        daoImplWriter.write("        return freeFind(sql); \r\n");
        daoImplWriter.write("    } \r\n");
        daoImplWriter.newLine();
        daoImplWriter.newLine();
        int count = metaData.getColumnCount();
        for(int i=1;i<=count;i++) {
            //列名 小写
            String columnName = metaData.getColumnName(i);
            String upperCaseColumnName = dao.toUpperCaseFirstOne(columnName);
            if(i==1){
                //主键
                daoImplWriter.write("    @Override \r\n");
                daoImplWriter.write("    public List findById(Object id) { \r\n");
                daoImplWriter.write("        String sql = \"select * from "+tableName+" where "+columnName+"='\"+id+\"'\"; \r\n");
                daoImplWriter.write("        return freeFind(sql); \r\n");
                daoImplWriter.write("    } \r\n");
                daoImplWriter.newLine();
                daoImplWriter.newLine();
            }else{
                daoImplWriter.write("    @Override \r\n");
                daoImplWriter.write("    public List findBy"+upperCaseColumnName+"(Object "+columnName+") { \r\n");
                daoImplWriter.write("        String sql = \"select * from "+tableName+" where "+columnName+"='\"+"+columnName+"+\"'\"; \r\n");
                daoImplWriter.write("        return freeFind(sql); \r\n");
                daoImplWriter.write("    } \r\n");
                daoImplWriter.newLine();
                daoImplWriter.newLine();
            }
        }

        daoImplWriter.newLine();
        daoImplWriter.newLine();
        daoImplWriter.write("}");
        daoImplWriter.close();
    }

    /**
     * Dao模板
     * @param upperCaseTableName
     * @param daoWriter
     * @param now
     * @throws IOException
     */
    private static void generateDao(ResultSetMetaData metaData,String upperCaseTableName, BufferedWriter daoWriter, String now) throws IOException, SQLException {
        daoWriter.write("package com.qhit."+tableName+".dao;");
        daoWriter.newLine();
        daoWriter.newLine();
        daoWriter.write("import com.qhit.utils.BaseDao;");
        daoWriter.newLine();
        daoWriter.write("import java.util.List;");
        daoWriter.newLine();
        daoWriter.newLine();
        daoWriter.write("/**");
        daoWriter.newLine();
        daoWriter.write("* Created by GeneratorCode on "+now);
        daoWriter.newLine();
        daoWriter.write("*/");
        daoWriter.newLine();
        daoWriter.newLine();
        daoWriter.write("public interface I"+upperCaseTableName+"Dao {");
        daoWriter.newLine();
        daoWriter.newLine();
        daoWriter.write("    boolean insert(Object object);");
        daoWriter.newLine();
        daoWriter.newLine();
        daoWriter.write("    boolean  update(Object object);");
        daoWriter.newLine();
        daoWriter.newLine();
        daoWriter.write("    boolean delete(Object object);");
        daoWriter.newLine();
        daoWriter.newLine();
        daoWriter.write("    List freeFind(String sql);");
        daoWriter.newLine();
        daoWriter.newLine();
        daoWriter.write("    List findAll();");
        daoWriter.newLine();
        daoWriter.newLine();
        daoWriter.write("    List findById(Object id);");
        daoWriter.newLine();
        daoWriter.newLine();
        int count = metaData.getColumnCount();
        for(int i=2;i<=count;i++) {
            //列名 小写
            String columnName = metaData.getColumnName(i);
            String upperCaseColumnName = dao.toUpperCaseFirstOne(columnName);
            daoWriter.write("    List findBy"+upperCaseColumnName+"(Object "+columnName+");");
            daoWriter.newLine();
            daoWriter.newLine();
        }
        daoWriter.write("}");
        daoWriter.close();
    }

    private static void generateServiceImpl(ResultSetMetaData metaData,String upperCaseTableName, BufferedWriter serviceImplWriter, String now) throws IOException, SQLException {
        serviceImplWriter.write("package com.qhit."+tableName+".service.impl;");
        serviceImplWriter.newLine();
        serviceImplWriter.newLine();
        serviceImplWriter.write("import com.qhit."+tableName+".service.I"+upperCaseTableName+"Service;");
        serviceImplWriter.newLine();
        serviceImplWriter.write("import java.util.List;");
        serviceImplWriter.newLine();
        serviceImplWriter.write("import com.qhit."+tableName+".dao.I"+upperCaseTableName+"Dao;");
        serviceImplWriter.newLine();
        serviceImplWriter.write("import com.qhit."+tableName+".dao.impl."+upperCaseTableName+"DaoImpl;");
        serviceImplWriter.newLine();
        serviceImplWriter.write("import com.qhit."+tableName+".pojo."+upperCaseTableName+";\r\n");
        serviceImplWriter.newLine();
        serviceImplWriter.write("/**");
        serviceImplWriter.newLine();
        serviceImplWriter.write("* Created by GeneratorCode on "+now);
        serviceImplWriter.newLine();
        serviceImplWriter.write("*/");
        serviceImplWriter.newLine();
        serviceImplWriter.newLine();
        serviceImplWriter.write("public class "+upperCaseTableName+"ServiceImpl  implements I"+upperCaseTableName+"Service {");
        serviceImplWriter.newLine();
        serviceImplWriter.newLine();
        serviceImplWriter.write("    I"+upperCaseTableName+"Dao dao = new "+upperCaseTableName+"DaoImpl();");
        serviceImplWriter.newLine();
        serviceImplWriter.newLine();
        serviceImplWriter.write("    @Override \r\n");
        serviceImplWriter.write("    public boolean insert(Object object) { \r\n");
        serviceImplWriter.write("        return dao.insert(object); \r\n");
        serviceImplWriter.write("    } \r\n");
        serviceImplWriter.newLine();
        serviceImplWriter.newLine();
        serviceImplWriter.write("    @Override \r\n");
        serviceImplWriter.write("    public boolean update(Object object) { \r\n");
        serviceImplWriter.write("        return dao.update(object); \r\n");
        serviceImplWriter.write("    } \r\n");
        serviceImplWriter.newLine();
        serviceImplWriter.newLine();
        serviceImplWriter.write("    @Override \r\n");
        serviceImplWriter.write("    public boolean delete(Object id) { \r\n");
        serviceImplWriter.write("        "+upperCaseTableName+" "+tableName+" = findById(id); \r\n");
        serviceImplWriter.write("        return dao.delete("+tableName+"); \r\n");
        serviceImplWriter.write("    } \r\n");
        serviceImplWriter.newLine();
        serviceImplWriter.newLine();
        serviceImplWriter.write("    @Override \r\n");
        serviceImplWriter.write("    public List findAll() { \r\n");
        serviceImplWriter.write("        return dao.findAll(); \r\n");
        serviceImplWriter.write("    } \r\n");
        serviceImplWriter.newLine();
        serviceImplWriter.newLine();
        serviceImplWriter.write("    @Override \r\n");
        serviceImplWriter.write("    public "+upperCaseTableName+" findById(Object id) { \r\n");
        serviceImplWriter.write("        List<"+upperCaseTableName+"> list = dao.findById(id); \r\n");
        serviceImplWriter.write("        return  list.get(0); \r\n");
        serviceImplWriter.write("    } \r\n");
        serviceImplWriter.newLine();
        serviceImplWriter.newLine();



        serviceImplWriter.newLine();
        serviceImplWriter.newLine();
        serviceImplWriter.write("}");
        serviceImplWriter.close();
    }

    /**
     * Service模板
     * @param upperCaseTableName
     * @param serviceWriter
     * @param now
     * @throws IOException
     */
    private static void generateService(ResultSetMetaData metaData,String upperCaseTableName, BufferedWriter serviceWriter, String now) throws IOException, SQLException {
        serviceWriter.write("package com.qhit."+tableName+".service;");
        serviceWriter.newLine();
        serviceWriter.newLine();
        serviceWriter.write("import java.util.List;");
        serviceWriter.newLine();
        serviceWriter.write("import com.qhit."+tableName+".pojo."+upperCaseTableName+";\r\n");
        serviceWriter.write("/**");
        serviceWriter.newLine();
        serviceWriter.write("* Created by GeneratorCode on "+now);
        serviceWriter.newLine();
        serviceWriter.write("*/");
        serviceWriter.newLine();
        serviceWriter.newLine();
        serviceWriter.write("public interface I"+upperCaseTableName+"Service {");
        serviceWriter.newLine();
        serviceWriter.newLine();
        serviceWriter.write("    boolean insert(Object object);");
        serviceWriter.newLine();
        serviceWriter.newLine();
        serviceWriter.write("    boolean  update(Object object);");
        serviceWriter.newLine();
        serviceWriter.newLine();
        serviceWriter.write("    boolean delete(Object id);");
        serviceWriter.newLine();
        serviceWriter.newLine();
        serviceWriter.write("    List findAll();");
        serviceWriter.newLine();
        serviceWriter.newLine();
        serviceWriter.write("    "+upperCaseTableName+" findById(Object id);");
        serviceWriter.newLine();
        serviceWriter.newLine();


        serviceWriter.write("}");
        serviceWriter.close();
    }


    //删除文件夹
    public static void delFolder(String folderPath) {
        try {
            delAllFile(folderPath); //删除完里面所有内容
            String filePath = folderPath;
            filePath = filePath.toString();
            File myFilePath = new File(filePath);
            myFilePath.delete(); //删除空文件夹
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //删除指定文件夹下所有文件
//param path 文件夹完整绝对路径
    public static boolean delAllFile(String path) {
        boolean flag = false;
        File file = new File(path);
        if (!file.exists()) {
            return flag;
        }
        if (!file.isDirectory()) {
            return flag;
        }
        String[] tempList = file.list();
        File temp = null;
        for (int i = 0; i < tempList.length; i++) {
            if (path.endsWith(File.separator)) {
                temp = new File(path + tempList[i]);
            } else {
                temp = new File(path + File.separator + tempList[i]);
            }
            if (temp.isFile()) {
                temp.delete();
            }
            if (temp.isDirectory()) {
                delAllFile(path + "/" + tempList[i]);//先删除文件夹里面的文件
                delFolder(path + "/" + tempList[i]);//再删除空文件夹
                flag = true;
            }
        }
        return flag;
    }

    /**
     * 创建文件夹
     */
    private static void makeSomeDirs(File dir) {
        File file1 = new File(dir.getAbsolutePath()+"\\com\\qhit\\"+tableName+"\\pojo");
        File file2 = new File(dir.getAbsolutePath()+"\\com\\qhit\\"+tableName+"\\dao\\impl");
        File file3 = new File(dir.getAbsolutePath()+"\\com\\qhit\\"+tableName+"\\service\\impl");
        file1.mkdirs();
        file2.mkdirs();
        file3.mkdirs();
    }

    /**
     * 查询字段的注释
     * @param conn
     * @param metaData
     * @return
     * @throws SQLException
     */
    private static String[] findComments(Connection conn,  ResultSetMetaData metaData) throws SQLException {
        //字段注释
        String[] comments = new String[metaData.getColumnCount()];
        String commentSql = "show full columns from "+tableName;
        PreparedStatement ps2 = conn.prepareStatement(commentSql);
        ResultSet set = ps2.executeQuery();
        int j = 0;
        while (set.next()){
            comments[j] = set.getString("Comment");
            j++;
        }
        return comments;
    }

}

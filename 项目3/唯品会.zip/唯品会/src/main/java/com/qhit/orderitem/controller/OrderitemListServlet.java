package com.qhit.orderitem.controller;

import com.qhit.orderitem.pojo.Orderitem;
import com.qhit.orderitem.service.IOrderitemService;
import com.qhit.orderitem.service.impl.OrderitemServiceImpl;
import com.qhit.orders.pojo.Orders;
import com.qhit.orders.service.IOrdersService;
import com.qhit.orders.service.impl.OrdersServiceImpl;
import com.qhit.utils.Page;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2018/11/8 0008.
 */
@WebServlet(name = "OrderitemListServlet",urlPatterns = "/OrderitemList")
public class OrderitemListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String currentPage =request.getParameter("currentPage");
        String pageSize =request.getParameter("pageSize");
        String oid =request.getParameter("oid");
        Page page=new Page();
        if (currentPage==null){
            page.setCurrentPage(1);
        }else{
            page.setCurrentPage(Integer.parseInt(currentPage));
        }
        if (pageSize==null){
            page.setPageSize(10);
        }else{
            page.setPageSize(Integer.parseInt(pageSize));
        }
        IOrderitemService service=new OrderitemServiceImpl();
        List<Orderitem> list=service.findBypage(page,oid);
        request.setAttribute("list",list);
        request.setAttribute("page",page);
        request.getRequestDispatcher("orderitem/OrderitemList.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}

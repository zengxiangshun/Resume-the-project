package com.qhit.categorysecond.pojo;

import com.qhit.category.pojo.Category;
import com.qhit.product.pojo.Product;
import com.sun.org.glassfish.gmbal.Description;

/**
* Created by GeneratorCode on 2018/10/14
*/

public class Categorysecond {

    private Integer csid;
    private String csname;
    private Integer cid;
    @Description("bean")
    private Category category;
    @Description("un")
    private String count;
    @Description("bean")
    private Product product;

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
    public Integer getCsid() {
        return csid;
    }
 
    public void setCsid(Integer csid) { 
        this.csid = csid;
    }
 
    public String getCsname() { 
        return csname;
    }
 
    public void setCsname(String csname) { 
        this.csname = csname;
    }
 
    public Integer getCid() { 
        return cid;
    }
 
    public void setCid(Integer cid) { 
        this.cid = cid;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
}
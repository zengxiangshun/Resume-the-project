package com.qhit.user.controller;

import com.qhit.adminuser.pojo.Adminuser;
import com.qhit.adminuser.service.IAdminuserService;
import com.qhit.adminuser.service.impl.AdminuserServiceImpl;
import com.qhit.user.pojo.User;
import com.qhit.user.service.IUserService;
import com.qhit.user.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Administrator on 2018/11/4 0004.
 */
@WebServlet(name = "UserEidtServlet",urlPatterns = "/UserEidt")
public class UserEidtServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uid = request.getParameter("uid");
        IUserService service=new UserServiceImpl();
        User user=service.findById(uid);
        request.setAttribute("user",user);
        request.getRequestDispatcher("user/UserEidt.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

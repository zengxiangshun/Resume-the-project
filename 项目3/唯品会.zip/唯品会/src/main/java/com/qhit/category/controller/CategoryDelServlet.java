package com.qhit.category.controller;

import com.qhit.category.service.ICategoryService;
import com.qhit.category.service.impl.CategoryServiceImpl;
import com.qhit.user.service.IUserService;
import com.qhit.user.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Administrator on 2018/11/4 0004.
 */
@WebServlet(name = "CategoryDelServlet",urlPatterns = "/CategoryDel")
public class CategoryDelServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String cid = request.getParameter("cid");
        ICategoryService service=new CategoryServiceImpl();
        boolean delete = service.delete(cid);
        if (delete){
            request.getRequestDispatcher("CategoryList").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

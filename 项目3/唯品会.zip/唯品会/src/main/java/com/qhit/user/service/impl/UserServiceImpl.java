package com.qhit.user.service.impl;

import com.qhit.user.service.IUserService;
import java.util.List;
import com.qhit.user.dao.IUserDao;
import com.qhit.user.dao.impl.UserDaoImpl;
import com.qhit.user.pojo.User;
import com.qhit.utils.Page;

/**
* Created by GeneratorCode on 2018/10/14
*/

public class UserServiceImpl  implements IUserService {

    IUserDao dao = new UserDaoImpl();

    @Override 
    public boolean insert(Object object) { 
        return dao.insert(object); 
    } 


    @Override 
    public boolean update(Object object) { 
        return dao.update(object); 
    } 


    @Override 
    public boolean delete(Object id) { 
        User user = findById(id); 
        return dao.delete(user); 
    } 


    @Override 
    public List findAll() { 
        return dao.findAll(); 
    } 


    @Override 
    public User findById(Object id) { 
        List<User> list = dao.findById(id); 
        return  list.get(0); 
    }

    @Override
    public boolean login(String username, String password) {
        String sql="SELECT * from user where username='"+username+"' and password='"+password+"'";
        List list=dao.freeFind(sql);
        if (list!=null && list.size()>0){
            return true;
        }
        return false;
    }

    @Override
    public List<User> findBypage(Page page, User user) {
        String sql="select cast(count(*) as char) as count from user ";
        String whereStr = "where 1=1";
        if(user.getUsername()!=null && !"".equals(user.getUsername())){
            whereStr+=" and username like '%"+user.getUsername()+"%'";
        }
        List<User> list = dao.freeFind(sql+whereStr);
        String totalCount=list.get(0).getCount();
        page.setTotalCount(Integer.parseInt(totalCount));
        int totalPage=page.getTotalCount()%page.getPageSize()==0?page.getTotalCount()/page.getPageSize():page.getTotalCount()/page.getPageSize()+1;
        page.setTotalPage(totalPage);
        int begin; int end;
        if (page.getTotalPage()<=10){
            begin=1;
            end=page.getTotalPage();
        }else if(page.getCurrentPage()<=5){
            begin=1;
            end=10;
        } else if (page.getCurrentPage()>=page.getTotalPage()-5){
            begin=page.getTotalPage()-9;
            end=page.getTotalPage();
        }else {
            begin=page.getCurrentPage()-4;
            end=page.getCurrentPage()+5;
        }
        page.setBegin(begin);
        page.setEnd(end);
        
        String sql1=" select * from user "+whereStr+" limit "+(page.getCurrentPage()-1)*page.getPageSize()+","+page.getPageSize();
        List<User> list1 = dao.freeFind(sql1);
        return list1;
    }


}